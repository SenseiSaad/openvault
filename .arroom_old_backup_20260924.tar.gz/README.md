# Ar Room — Room Reconstruction & AR Furniture Pipeline

Turn a walkthrough video (or 20–40 overlapping photos) of a room into a **scaled,
photorealistic 3D scene** you can explore in the browser and decorate with real-scale
furniture.

```
video/photos ─▶ frames ─▶ COLMAP (SfM) ─▶ gsplat (3D Gaussian Splatting)
                                  │
                                  └─▶ Open3D (mesh + RANSAC floor/wall planes)
                                           │
                          scale calibration (known object / AR metric)
                                           │
                                  Three.js viewer + furniture placement
```

Everything is free / open-source and runs locally. See **[SETUP.md](SETUP.md)** for the
one-time install of the heavy tools (COLMAP, gsplat, Open3D) and **[docs/PIPELINE.md](docs/PIPELINE.md)**
for what each stage does.

## Quick start (dev)

```bash
# 1. infra: MinIO (S3) + Redis
docker compose up -d

# 2. backend
cd backend
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp ../.env.example .env          # edit if needed
python manage.py migrate
python manage.py createsuperuser # optional, for /admin
python manage.py runserver

# 3. worker (second terminal, same venv)
cd backend && source .venv/bin/activate
celery -A config worker -l info
```

Open <http://localhost:8000/> — upload a video, watch the job progress, then open the
viewer when it's `DONE`.

## Layout

| Path | What |
|------|------|
| `backend/config/` | Django project (settings, celery, urls) |
| `backend/reconstruction/` | The app: models, API, storage, Celery tasks |
| `backend/reconstruction/pipeline/` | The real work: frames, colmap, splat, geometry, scale |
| `backend/reconstruction/templates/` | Upload UI + viewer pages |
| `backend/reconstruction/static/` | JS/CSS (Three.js splat viewer, furniture) |
| `docker-compose.yml` | MinIO + Redis |
| `furniture/` | Drop `.glb` furniture models here (catalog) |

## Status of the heavy tools

The pipeline shells out to `colmap`, `ns-train`/`gsplat`, and imports `open3d`. If a tool
isn't installed the job fails **at that stage with a clear message** rather than silently —
so you always know what's missing. Install per [SETUP.md](SETUP.md).
