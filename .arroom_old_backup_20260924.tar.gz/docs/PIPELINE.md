# Pipeline internals

The orchestrator is `reconstruction/pipeline/runner.py`. It runs five stages, updating the
`Scene` row (`status`, `stage`, `progress`, `log`, `error`) as it goes so the UI can poll.

| # | Stage | Module | Input | Output | External tool |
|---|-------|--------|-------|--------|---------------|
| 1 | frames | `frames.py` | video/zip | `images/*.jpg` | ffmpeg |
| 2 | colmap | `colmap.py` | images | camera poses + `sparse/0/points.ply` | COLMAP |
| 3 | splat | `splat.py` | colmap dir | `scene.ply` splat | ns-train/ns-export (gsplat) |
| 4 | geometry | `geometry.py` | `points.ply` | floor/wall planes JSON | open3d (RANSAC) |
| 5 | scale | `scale.py` | planes + inputs | metric `scale_factor` | — |

## Stage notes

**frames** — video → ~`TARGET_FRAMES` evenly spaced frames (fps chosen from duration);
photos → unzipped directly. Enforces `MIN_FRAMES`.

**colmap** — `feature_extractor` → `exhaustive_matcher` → `mapper`, using GPU SIFT when
`nvidia-smi` is present. Output is laid out for Nerfstudio's colmap dataparser
(`images/` + `sparse/0/`). Sparse points are exported as PLY for stage 4.

**splat** — `ns-train splatfacto --data <colmap_dir>` then `ns-export gaussian-splat` →
a `.ply` the browser viewer loads.

**geometry** — Open3D iterative `segment_plane` (RANSAC). The largest plane defines the
**up axis**; planes are classified floor / ceiling / wall by their normal vs up. Emits
`up_axis`, per-plane `{normal, d, centroid, extent, type}`, and the room bounding box.

**scale** — reconstruction has no metric scale. Two strategies:
- `KNOWN_OBJECT`: `reference_length_m` maps to a raw span — either two picked points in
  `metadata.ref_points`, or (fallback) the largest floor extent.
- `AR`: reads an ARKit/ARCore `transforms.json` sidecar (metric) and takes the ratio of
  its camera-track bbox diagonal to the reconstruction's.

The factor multiplies all plane/bbox coordinates → metres. The viewer applies the **same**
factor as the splat scene scale, so splats, planes, and metric furniture all align.

## Where scale + geometry matter for the viewer

`viewer.js` reads `scene.planes` (metric) to build a `THREE.Plane` for the floor and to
report room dimensions, and applies `scale_factor` to the splat scene so shift-click
placement drops furniture at the correct real-world size and height.

## Extending

- **More robust up/gravity**: feed the AR gravity vector into `geometry._estimate_up`.
- **Wall snapping**: `viewer.js` currently snaps to the floor plane; add the wall planes
  the same way (they're already in the JSON with `type: "wall"`).
- **Meshing**: swap the sparse PLY for the splat's densified points, or run Poisson
  reconstruction in `geometry.py` for a solid mesh export.
