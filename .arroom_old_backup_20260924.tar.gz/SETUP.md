# Setup — installing the heavy tools

The web app (Django + Celery + viewer) runs from `backend/requirements.txt`. The three
GPU/CV tools are installed separately because they're large and platform-specific.

## 0. Infra (any machine)

```bash
docker compose up -d          # MinIO on :9000/:9001, Redis on :6379
```

MinIO console: <http://localhost:9001> (minioadmin / minioadmin). The `arroom` bucket is
auto-created. To skip MinIO entirely, set `USE_S3=False` in `.env` (files stay on local disk).

## 1. Backend + worker

```bash
cd backend
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp ../.env.example .env
python manage.py makemigrations reconstruction
python manage.py migrate
python manage.py runserver          # terminal 1
celery -A config worker -l info     # terminal 2 (same venv)
```

> Quick test without a worker or Redis: set `CELERY_TASK_ALWAYS_EAGER=True` in `.env` and
> the pipeline runs inline on upload.

## 2. FFmpeg (frame extraction)

```bash
sudo apt install ffmpeg          # Debian/Ubuntu
# brew install ffmpeg            # macOS
```

## 3. COLMAP (Structure-from-Motion)

```bash
sudo apt install colmap          # simplest; CPU or CUDA build depending on distro
# or build from source with CUDA for big speedups: https://colmap.github.io/install.html
```

Verify: `colmap -h`. If it's not on PATH, set `COLMAP_BIN=/full/path/to/colmap` in `.env`.

## 4. Gaussian Splatting (Nerfstudio + gsplat)

Needs an NVIDIA GPU + CUDA. Install **into the same venv**:

```bash
source backend/.venv/bin/activate
pip install torch --index-url https://download.pytorch.org/whl/cu121   # match your CUDA
pip install nerfstudio            # brings in gsplat + ns-train/ns-export
```

Verify: `ns-train --help` and `ns-export --help`. On the RTX 4050, keep
`--max-num-iterations` around 7k–15k for small rooms (set in `pipeline/splat.py`).

## 5. Open3D (plane extraction)

Already in `requirements.txt` (`pip install open3d`). No GPU required.

## What if a tool is missing?

The job fails **at that stage** with a message naming the tool and how to install it — check
the scene's error on the home page or its `log` field in `/admin`. Nothing fails silently.
