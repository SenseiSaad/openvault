# RoomScale — Project Information

> **One-line title:**
> **RoomScale** — turn an ordinary phone video of a room into a scaled, photorealistic 3D
> space you can walk through in your browser and furnish with true-to-size furniture.
>
> *(Working folder is currently "Ar Room" — see [Name ideas](#12-name-ideas) for the rename.)*

---

## 1. What is this project, in plain English?

You walk around a room holding your phone and record a short video. You upload that video
to this app. A few minutes later you get back a **3D copy of that exact room** on a web
page — the real walls, floor, furniture, lighting — that you can spin around, zoom into,
and look at from any angle, like a video game level made from your real room.

On top of that, the app knows **how big the room really is** (in metres) and where the
**floor and walls** are. So you can drag a sofa or a table into the 3D room and it appears
at the **correct real-world size** in the **correct spot**. It's a "try before you buy /
before you move things" tool for interior spaces.

The clever, hard parts this project solves itself (the rest is glued-together open tools):
- **Orchestration** — taking a messy video and pushing it through 4–5 heavy tools without
  the user touching a command line.
- **Scale calibration** — a normal video has *no idea* how big anything is; this project
  figures out real metres.
- **Geometry cleanup** — finding "this is the floor, that's a wall" out of a cloud of points.

---

## 2. Background story — why build this?

Tools that scan rooms into 3D already exist — but the good ones are **closed, paid, and
cloud-locked**. Matterport needs special cameras and subscriptions. Polycam and Luma are
phone apps that upload your data to their servers and charge for exports. Apple's RoomPlan
only works on recent iPhones/iPads with a LiDAR sensor.

There was **no clean, open, self-hostable pipeline** that a student could run end-to-end on
their own hardware and understand every step of — especially the genuinely fiddly middle
bits (scale calibration, plane detection, job orchestration) that the polished apps hide.

So the idea: **stitch the best free/open-source tools (COLMAP, gsplat, Open3D, Three.js)
into one automated pipeline**, add the missing glue (real-world scaling + surface detection
+ a friendly web app), and make the whole thing run for free on a laptop with a modest GPU,
scaling up to the cloud only when a room is too big. It's a Final-Year-Project-sized system
that is also genuinely useful and demo-able.

---

## 3. How it works — the journey of one video

```
 1. CAPTURE        You record a slow walk around the room (or 20–40 overlapping photos).
        │
 2. UPLOAD         Video goes to the Django backend, saved to storage (MinIO/S3).
        │          A background job is queued so the website stays responsive.
        ▼
 3. FRAMES         ffmpeg chops the video into ~150 sharp, evenly-spaced still images.
        │
 4. SfM (COLMAP)   Looks at all the photos, matches the same corners/edges across them,
        │          and works out WHERE the camera was for each shot + a rough 3D dot-cloud.
        ▼
 5. SPLATTING      gsplat/Nerfstudio turns those photos+positions into millions of tiny
    (gsplat)       coloured 3D blobs that recreate the room photorealistically.
        │
 6. GEOMETRY       Open3D looks at the dot-cloud and finds the flat surfaces:
    (Open3D)       "this big horizontal one is the FLOOR, these vertical ones are WALLS."
        │
 7. SCALE          The scene is resized to real metres, using either a known-size object
        │          in view, or phone AR/LiDAR data recorded alongside.
        ▼
 8. VIEWER         The finished, scaled room loads in the browser (Three.js). You orbit,
        │          zoom, and drag furniture that snaps to the floor at the right size.
        ▼
 9. (Optional AI)  Style detection / furniture recommendation on top.
```

**Where the pieces live in the code:**

| Step | Code |
|------|------|
| Upload + jobs | `backend/reconstruction/` (models, API, `tasks.py`) |
| The 5 stages | `backend/reconstruction/pipeline/` (`frames`, `colmap`, `splat`, `geometry`, `scale`) |
| Orchestrator | `backend/reconstruction/pipeline/runner.py` |
| Viewer + furniture | `backend/reconstruction/templates/viewer.html` + `static/js/viewer.js` |

---

## 4. Current functionalities (what is actually built right now)

✅ Upload a video **or** a zip of photos through a clean web page.
✅ Background job queue (Celery + Redis) so heavy processing never blocks the site.
✅ Object storage that works two ways: **MinIO/S3**, or plain **local disk** (one setting).
✅ Full 5-stage pipeline wired end-to-end, each stage reporting **live progress %** and a log.
✅ **Honest failure**: if COLMAP/gsplat/Open3D isn't installed, the job stops at that exact
   stage with a message telling you what to install — nothing fails silently.
✅ Two **scale-calibration** methods: known-size object, or AR/metric sidecar file.
✅ **Floor/wall detection** with automatic up-axis guess and room-size estimate.
✅ Browser **splat viewer** (orbit / zoom / pan) with **shift-click furniture placement**
   that snaps to the floor at correct real-world scale (built-in 1 m box works with zero
   downloads; drop `.glb` models in for a real catalog).
✅ Django **admin** for inspecting every scene, its status, and logs.
✅ Poll-based UI that refreshes scene status automatically.

**Not yet done (deliberately left for the GPU laptop / later):** running the actual GPU
training, a committed DB migration, user accounts/auth, and the optional AI layer.

<!-- APPEND_MARKER_2 -->

---

## 5. Who are the competitors?

| Product | What it does | Where you differ |
|---------|--------------|------------------|
| **Matterport** | Industry standard for 3D property tours | Needs special cameras + paid subscription; yours is open & free |
| **Polycam** | Phone LiDAR/photo → 3D scan | Cloud-only, paywalled exports; yours is self-hosted, you own the data |
| **Luma AI** | Phone video → NeRF/splat, very polished | Closed cloud service; yours is open pipeline you can modify |
| **Scaniverse / KIRI Engine** | Free-ish phone 3D scanning apps | Phone-app only, not a customizable web platform |
| **Apple RoomPlan** | Instant room floorplan + dimensions | LiDAR iPhone/iPad only; yours works from any phone video |
| **IKEA Place / Houzz / Amazon View in Room** | AR "place furniture in my room" | They use live-camera AR, no persistent reconstructed 3D room; yours saves a full explorable 3D scene |
| **Planner5D / Roomstyler** | Manual room-design tools | You draw the room by hand there; yours *captures* the real room automatically |
| **Nerfstudio / COLMAP (tools)** | The engines under the hood | These are libraries, not a product; your project is the *product* built on them |

**Your niche in one sentence:** an **open-source, self-hostable web app** that produces a
**metrically-scaled, furnishable 3D room** from a **plain phone video** — no special
hardware, no cloud lock-in, no subscription.

---

## 6. Pros and cons

**Pros**
- 💸 **Free & open** — zero licensing cost, runs on your own hardware.
- 🔓 **No data lock-in** — the room, the splat, the data all stay with you.
- 📱 **No special hardware** — any phone video works (no LiDAR required).
- 📏 **Real-world scale** — the hard problem most hobby projects skip is solved here.
- 🧩 **Modular** — swap any stage (different splat trainer, different matcher) freely.
- 🎓 **Great FYP scope** — touches web, async jobs, computer vision, 3D graphics, and AI.

**Cons / honest limitations**
- 🐢 **Not instant** — reconstruction takes minutes and needs a decent GPU.
- 🎥 **Garbage-in-garbage-out** — a shaky, dark, or low-overlap video reconstructs badly.
- 📐 **Scale needs a reference** — pure video can't self-measure; you must give an object
  size or AR data.
- 🧱 **Plane detection is approximate** — cluttered rooms confuse floor/wall fitting.
- 🖥️ **GPU dependency** — big/dense rooms outgrow a laptop 4050 and need cloud GPU.
- 🔧 **Setup effort** — COLMAP + Nerfstudio installation is heavier than a normal web app.

---

## 7. What is the minimum working version (MVP)?

The smallest thing that still *wows* someone in a demo. Aim for this first:

1. Upload **one prepared video** (you pre-record a good, well-lit, high-overlap room).
2. Pipeline runs on your **local 4050**: frames → COLMAP → gsplat → splat file.
3. Scene opens in the **browser viewer** and you can **orbit/zoom** the real room. ✅ *This
   alone is already impressive.*
4. **Scale** with the simplest method (known object) so the room reads in metres.
5. Drop **one `.glb` chair** (or the built-in box) onto the floor.

If steps 1–3 work, you have a defensible project. Steps 4–5 make it *complete*. Everything
else is polish.

> Tip: for the MVP, set `USE_S3=False` and `CELERY_TASK_ALWAYS_EAGER=True` in `.env` — then
> you don't even need MinIO, Redis, or a worker. Just Django + the CV tools. Fewer moving
> parts on demo day.

<!-- APPEND_MARKER_3 -->

---

## 8. What else can you add? (Roadmap ideas, easy → ambitious)

**Easy wins**
- User accounts + "my rooms" gallery.
- Drag-and-drop upload with a progress bar; thumbnail per scene.
- A real furniture catalog page with previews (from Sketchfab/Poly Haven `.glb`s).
- Save & reload furniture arrangements (store placements in the DB per scene).
- Download the finished splat / a screenshot / a short orbit video.

**Medium**
- **Wall snapping** (already have wall planes in the data — snap pictures/shelves to walls).
- **Measure tool** in the viewer: click two points, get the real distance.
- **Auto floorplan**: top-down 2D plan generated from the detected planes.
- **Mesh export** (`.obj`/`.glb`) via Poisson reconstruction for use in Blender/game engines.
- Email/websocket notification when a job finishes (instead of polling).

**Ambitious / the "optional AI layer"**
- **Style classifier**: detect if the room is modern/rustic/minimal from the images.
- **Furniture recommendation**: suggest items that fit the room's style *and* free space.
- **Auto-staging**: AI fills an empty room with sensibly-placed furniture.
- **Semantic segmentation**: label windows, doors, and existing furniture, not just planes.
- **Multi-room stitching**: combine several scans into a whole apartment.

---

## 9. Minimum AWS infrastructure

You can run 100% locally for free. Reach for AWS only when (a) a room is too heavy for the
4050, or (b) you want a public, always-on demo for your defense.

**Cheapest realistic setup (single-box):**
| Piece | AWS service | Why | Rough cost note |
|-------|-------------|-----|-----------------|
| GPU compute | **1× EC2 `g4dn.xlarge`** (T4 GPU), **Spot** | Runs COLMAP + gsplat; also hosts Django/Celery/Redis via docker-compose | Cheap on Spot; **stop it when idle** |
| File storage | **1× S3 bucket** | Videos + finished splats (your code already talks S3) | Pennies for a demo |
| Public address | **Elastic IP** (or a Cloudflare tunnel) | Stable URL for the demo | ~free while attached |

That's genuinely the minimum: **S3 + one GPU EC2 instance**. Everything else (Redis, the DB,
the web server) rides on that one instance using your existing `docker-compose.yml`.

**Slightly more "proper" (if you want to show architecture maturity):**
- **RDS (PostgreSQL, db.t4g.micro)** instead of SQLite — set `DATABASE_URL`.
- **SQS + ElastiCache** or keep **Celery+Redis** — Celery can use SQS as broker if you prefer
  the managed queue mentioned in your brief.
- **S3 + CloudFront** to serve the (large) splat files fast to the browser.
- **Auto Scaling / a job queue that spins a GPU instance up per job and down after** — this
  is the cost-smart pattern: no idle GPU bill.

> ⚠️ **Cost caution:** GPU instances are the expensive part. Always use Spot for batch jobs,
> and shut the instance down between demos. For exact current prices, use the
> **AWS Pricing Calculator** — don't trust hard-coded numbers.

<!-- APPEND_MARKER_4 -->

---

## 10. How to add GitHub Actions (after the project works)

GitHub Actions = a robot that automatically checks/builds your code every time you push. You
add it **once the code is stable**, so it guards against breaking things later.

**Step 0 — put the project on GitHub.** This folder isn't a git repo yet:
```bash
cd "path/to/RoomScale"
git init && git add . && git commit -m "Initial RoomScale pipeline"
git branch -M main
git remote add origin https://github.com/<you>/roomscale.git
git push -u origin main
```

**A sensible CI ladder (add these in order):**

1. **Lint + syntax + migrations check** (fast, no GPU) — runs on every push/PR. A starter
   file is already provided at **`.github/workflows/ci.yml`**. It:
   - installs the light web deps,
   - runs `python -m py_compile` / `ruff` (lint),
   - runs `python manage.py makemigrations --check` and `manage.py check`.
   *(It deliberately does NOT install COLMAP/gsplat — those are too heavy for CI.)*

2. **Unit tests** — add `pytest`/Django tests for the non-GPU logic (scale maths in
   `scale.py`, plane classification, API endpoints with a fake job). CI runs them.

3. **Docker build** — a workflow that builds a backend Docker image and pushes it to GitHub
   Container Registry (`ghcr.io`) on every tag. Proves the app packages cleanly.

4. **Deploy (optional)** — on push to `main`, SSH into your EC2 GPU box and
   `git pull && docker compose up -d --build`. Store the SSH key in GitHub **Secrets**.

**Golden rules for CI here:**
- Keep the heavy CV tools OUT of CI — mock them. CI checks *your* code, not COLMAP.
- Put all secrets (`DJANGO_SECRET_KEY`, AWS keys, SSH keys) in **GitHub → Settings →
  Secrets**, never in the repo.
- Make the lint/test workflow **required** to merge a PR — that's what keeps `main` healthy.

---

## 11. Mini-glossary (jargon in one line each)

- **SfM (Structure from Motion)** — figuring out camera positions from overlapping photos.
- **COLMAP** — the free tool that does SfM.
- **Gaussian Splatting** — representing a scene as millions of tiny coloured 3D blobs;
  looks photorealistic and renders fast.
- **gsplat / Nerfstudio / splatfacto** — the free tools that train a splat.
- **Point cloud** — a scatter of 3D dots (rough shape of the scene).
- **RANSAC** — a method that finds a flat surface hiding inside noisy points.
- **Open3D** — the free library doing the plane-finding.
- **Scale calibration** — teaching the scene how big it is in real metres.
- **Three.js** — the browser 3D library that draws the scene.
- **`.glb`** — a single-file 3D model format (used for the furniture).
- **Celery / Redis** — the "do this heavy work in the background" system.
- **MinIO** — free storage that behaves exactly like Amazon S3.

---

## 12. Name ideas

The folder is "Ar Room" (a placeholder). Names that reflect *what it does* — capture a real
room and get real scale:

| Name | Why it fits |
|------|-------------|
| **RoomScale** ⭐ (recommended) | Captures the two headline features: it's a *room* and it's correctly *scaled*. Short, brandable, .com-able-ish. |
| **SplatSpace** | Says "Gaussian splat" + "3D space"; techy and catchy. |
| **Reroom** | "Reconstruct a room" / "re-do a room"; very short. |
| **SceneScale** | Emphasises scaled reconstruction; a bit more generic than rooms. |
| **RoomForge** | "Forge a 3D room from video"; strong, tool-like feel. |
| **TrueRoom** | Highlights the real, true-to-life, true-scale reconstruction. |

**Recommendation: `RoomScale`** — it's the clearest match to the project's unique value
(real rooms at real scale) and reads well as a product name and a repo name (`roomscale`).

---

*Generated as project documentation. Pair this with [README.md](README.md) (quick start),
[SETUP.md](SETUP.md) (installing tools), and [docs/PIPELINE.md](docs/PIPELINE.md) (stage
internals).*
