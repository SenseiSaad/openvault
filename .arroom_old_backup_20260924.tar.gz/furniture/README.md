# Furniture models

Drop `.glb` / `.gltf` files here (or in `backend/reconstruction/static/furniture/`)
and list them in `static/furniture/manifest.json`.

Free sources (free-license filter):
- Sketchfab — https://sketchfab.com/features/free-3d-models
- Poly Haven — https://polyhaven.com/models
- Free3D — https://free3d.com

Models should be authored **Y-up** and in **metres** so they match the calibrated
scene scale. The viewer's built-in "Box (1m)" item works with no downloads.
