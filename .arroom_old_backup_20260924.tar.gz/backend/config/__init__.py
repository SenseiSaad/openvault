"""Expose the Celery app so `@shared_task`s register on Django start."""
from .celery import app as celery_app

__all__ = ("celery_app",)
