import uuid

from django.db import models


class Scene(models.Model):
    """One captured room = one reconstruction job + its artifacts."""

    class Status(models.TextChoices):
        QUEUED = "QUEUED", "Queued"
        RUNNING = "RUNNING", "Running"
        DONE = "DONE", "Done"
        FAILED = "FAILED", "Failed"

    class Source(models.TextChoices):
        VIDEO = "VIDEO", "Video"
        PHOTOS = "PHOTOS", "Photos (zip)"

    class ScaleMethod(models.TextChoices):
        NONE = "NONE", "Not calibrated"
        KNOWN_OBJECT = "KNOWN_OBJECT", "Known-size object"
        AR = "AR", "AR / metric depth"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=200, blank=True)
    source_type = models.CharField(max_length=10, choices=Source.choices, default=Source.VIDEO)

    # Original upload. Stored under MEDIA_ROOT/uploads/ and (optionally) mirrored to S3.
    upload = models.FileField(upload_to="uploads/")

    # ── Job state ──────────────────────────────────────────
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.QUEUED)
    stage = models.CharField(max_length=40, blank=True, help_text="Current pipeline stage")
    progress = models.PositiveSmallIntegerField(default=0)  # 0..100
    error = models.TextField(blank=True)
    log = models.TextField(blank=True)

    # ── Scale calibration inputs ───────────────────────────
    scale_method = models.CharField(
        max_length=15, choices=ScaleMethod.choices, default=ScaleMethod.NONE
    )
    # Real-world length (metres) of the reference used for KNOWN_OBJECT calibration.
    reference_length_m = models.FloatField(null=True, blank=True)
    # Computed metres-per-splat-unit. 1.0 until calibrated.
    scale_factor = models.FloatField(default=1.0)

    # ── Output artifact locations (object keys / URLs) ─────
    splat_key = models.CharField(max_length=500, blank=True)
    mesh_key = models.CharField(max_length=500, blank=True)
    sparse_key = models.CharField(max_length=500, blank=True)
    # Detected floor/wall planes + room bbox, in metric units. See pipeline/geometry.py.
    planes = models.JSONField(default=dict, blank=True)
    metadata = models.JSONField(default=dict, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.name or 'Scene'} ({self.id})"

    # ── Convenience helpers used by the Celery pipeline ────
    def set_stage(self, stage: str, progress: int):
        self.stage = stage
        self.progress = progress
        self.status = self.Status.RUNNING
        self.save(update_fields=["stage", "progress", "status", "updated_at"])

    def append_log(self, line: str):
        self.log = (self.log + line.rstrip() + "\n")[-20000:]  # keep last ~20 KB
        self.save(update_fields=["log", "updated_at"])

    def mark_failed(self, message: str):
        self.status = self.Status.FAILED
        self.error = message
        self.save(update_fields=["status", "error", "updated_at"])

    def mark_done(self):
        self.status = self.Status.DONE
        self.stage = "done"
        self.progress = 100
        self.save(update_fields=["status", "stage", "progress", "updated_at"])
