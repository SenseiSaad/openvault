from django.shortcuts import get_object_or_404
from django.views.generic import TemplateView
from rest_framework import status
from rest_framework.decorators import api_view, parser_classes
from rest_framework.parsers import FormParser, MultiPartParser
from rest_framework.response import Response

from .models import Scene
from .serializers import SceneCreateSerializer, SceneSerializer
from .tasks import run_pipeline


# ── Pages ──────────────────────────────────────────────────
class IndexView(TemplateView):
    template_name = "index.html"


class ViewerView(TemplateView):
    template_name = "viewer.html"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["scene_id"] = kwargs.get("scene_id")
        return ctx


# ── API ────────────────────────────────────────────────────
@api_view(["GET", "POST"])
@parser_classes([MultiPartParser, FormParser])
def scene_list_create(request):
    if request.method == "GET":
        scenes = Scene.objects.all()
        return Response(SceneSerializer(scenes, many=True).data)

    serializer = SceneCreateSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    scene = serializer.save()
    # Kick off the async pipeline; returns immediately.
    run_pipeline.delay(str(scene.id))
    return Response(SceneSerializer(scene).data, status=status.HTTP_201_CREATED)


@api_view(["GET"])
def scene_detail(request, scene_id):
    scene = get_object_or_404(Scene, id=scene_id)
    return Response(SceneSerializer(scene).data)


@api_view(["POST"])
def scene_reprocess(request, scene_id):
    """Re-run the pipeline for a scene (e.g. after changing scale settings)."""
    scene = get_object_or_404(Scene, id=scene_id)
    scene.status = Scene.Status.QUEUED
    scene.progress = 0
    scene.error = ""
    scene.save(update_fields=["status", "progress", "error"])
    run_pipeline.delay(str(scene.id))
    return Response(SceneSerializer(scene).data)
