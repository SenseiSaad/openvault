from django.urls import path

from . import views

urlpatterns = [
    # Pages
    path("", views.IndexView.as_view(), name="index"),
    path("viewer/<uuid:scene_id>/", views.ViewerView.as_view(), name="viewer"),
    # API
    path("api/scenes/", views.scene_list_create, name="scene-list-create"),
    path("api/scenes/<uuid:scene_id>/", views.scene_detail, name="scene-detail"),
    path("api/scenes/<uuid:scene_id>/reprocess/", views.scene_reprocess, name="scene-reprocess"),
]
