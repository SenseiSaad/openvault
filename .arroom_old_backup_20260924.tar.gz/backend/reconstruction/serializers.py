from rest_framework import serializers

from . import storage
from .models import Scene


class SceneSerializer(serializers.ModelSerializer):
    """Read serializer — includes browser-ready URLs for the viewer."""

    splat_url = serializers.SerializerMethodField()
    mesh_url = serializers.SerializerMethodField()
    sparse_url = serializers.SerializerMethodField()

    class Meta:
        model = Scene
        fields = [
            "id", "name", "source_type", "status", "stage", "progress",
            "error", "scale_method", "reference_length_m", "scale_factor",
            "planes", "metadata", "created_at", "updated_at",
            "splat_url", "mesh_url", "sparse_url",
        ]
        read_only_fields = fields

    def get_splat_url(self, obj):
        return storage.public_url(obj.splat_key)

    def get_mesh_url(self, obj):
        return storage.public_url(obj.mesh_key)

    def get_sparse_url(self, obj):
        return storage.public_url(obj.sparse_key)


class SceneCreateSerializer(serializers.ModelSerializer):
    """Write serializer for the upload endpoint."""

    class Meta:
        model = Scene
        fields = ["name", "source_type", "upload", "scale_method", "reference_length_m"]

    def validate(self, attrs):
        if attrs.get("scale_method") == Scene.ScaleMethod.KNOWN_OBJECT and not attrs.get(
            "reference_length_m"
        ):
            raise serializers.ValidationError(
                "reference_length_m is required when scale_method is KNOWN_OBJECT."
            )
        return attrs
