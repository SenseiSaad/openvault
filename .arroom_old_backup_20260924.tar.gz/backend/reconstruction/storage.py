"""Thin object-storage wrapper.

The pipeline always works against local files (COLMAP/gsplat need real paths on
disk). This module handles pushing the *results* to MinIO/S3 and building URLs the
browser can load. When USE_S3 is False everything stays under MEDIA_ROOT and we
return normal /media/ URLs instead.
"""
from __future__ import annotations

import mimetypes
from pathlib import Path

from django.conf import settings


def _client():
    import boto3
    from botocore.config import Config

    return boto3.client(
        "s3",
        endpoint_url=settings.S3_ENDPOINT_URL,
        aws_access_key_id=settings.S3_ACCESS_KEY,
        aws_secret_access_key=settings.S3_SECRET_KEY,
        region_name=settings.S3_REGION,
        config=Config(signature_version="s3v4"),
    )


def ensure_bucket():
    """Create the bucket if it doesn't exist (idempotent)."""
    if not settings.USE_S3:
        return
    c = _client()
    existing = [b["Name"] for b in c.list_buckets().get("Buckets", [])]
    if settings.S3_BUCKET not in existing:
        c.create_bucket(Bucket=settings.S3_BUCKET)


def upload_file(local_path: str | Path, key: str) -> str:
    """Upload a local file and return an object key (S3) or media path (local)."""
    local_path = Path(local_path)
    if not settings.USE_S3:
        # Copy into MEDIA_ROOT/<key> so it's served by Django's media handler.
        dest = Path(settings.MEDIA_ROOT) / key
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.resolve() != local_path.resolve():
            dest.write_bytes(local_path.read_bytes())
        return key

    content_type = mimetypes.guess_type(str(local_path))[0] or "application/octet-stream"
    _client().upload_file(
        str(local_path),
        settings.S3_BUCKET,
        key,
        ExtraArgs={"ContentType": content_type},
    )
    return key


def public_url(key: str) -> str:
    """Build a browser-loadable URL for a stored object key."""
    if not key:
        return ""
    if not settings.USE_S3:
        return f"{settings.MEDIA_URL}{key}"
    base = settings.S3_ENDPOINT_URL.rstrip("/")
    return f"{base}/{settings.S3_BUCKET}/{key}"


def download_file(key: str, local_path: str | Path) -> Path:
    """Pull an object back to local disk (used by the worker if needed)."""
    local_path = Path(local_path)
    local_path.parent.mkdir(parents=True, exist_ok=True)
    if not settings.USE_S3:
        src = Path(settings.MEDIA_ROOT) / key
        local_path.write_bytes(src.read_bytes())
        return local_path
    _client().download_file(settings.S3_BUCKET, key, str(local_path))
    return local_path
