"""Stage 1 — turn the upload into a folder of input images.

Video  -> ffmpeg samples ~TARGET_FRAMES evenly spaced frames.
Photos -> unzip the archive; images are used directly.
"""
from __future__ import annotations

import json
import zipfile
from pathlib import Path

from django.conf import settings

from . import StageError, require_tool, run_command

_IMG_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


def extract_frames(upload_path: Path, source_type: str, out_dir: Path, log) -> int:
    """Populate out_dir with images. Returns the image count."""
    out_dir.mkdir(parents=True, exist_ok=True)

    if source_type == "PHOTOS":
        return _extract_photos(upload_path, out_dir, log)
    return _extract_video(upload_path, out_dir, log)


def _extract_photos(archive: Path, out_dir: Path, log) -> int:
    if not zipfile.is_zipfile(archive):
        raise StageError("Photos upload must be a .zip of images.")
    count = 0
    with zipfile.ZipFile(archive) as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            ext = Path(info.filename).suffix.lower()
            if ext not in _IMG_EXT:
                continue
            # Flatten into out_dir with a safe name.
            target = out_dir / f"frame_{count:05d}{ext}"
            with zf.open(info) as src, open(target, "wb") as dst:
                dst.write(src.read())
            count += 1
    log(f"Unpacked {count} photos.")
    if count < settings.MIN_FRAMES:
        raise StageError(f"Only {count} photos; need at least {settings.MIN_FRAMES}.")
    return count


def _extract_video(video: Path, out_dir: Path, log) -> int:
    ffmpeg = require_tool(
        settings.FFMPEG_BIN, "Install ffmpeg (e.g. `sudo apt install ffmpeg`)."
    )
    target = settings.TARGET_FRAMES

    # Two-pass: probe duration to pick an fps that yields ~target frames.
    fps = _choose_fps(video, target, log)
    run_command(
        [
            ffmpeg, "-i", str(video),
            "-vf", f"fps={fps:.4f},scale='min(1600,iw)':-2",
            "-qscale:v", "2",
            str(out_dir / "frame_%05d.jpg"),
        ],
        log=log,
    )
    count = len([p for p in out_dir.iterdir() if p.suffix.lower() in _IMG_EXT])
    log(f"Extracted {count} frames at {fps:.3f} fps.")
    if count < settings.MIN_FRAMES:
        raise StageError(
            f"Only {count} frames extracted; need >= {settings.MIN_FRAMES}. "
            "Record a longer / slower walkthrough."
        )
    return count


def _choose_fps(video: Path, target: int, log) -> float:
    """Pick fps so a video yields ~target frames. Defaults to 2 fps if probe fails."""
    import subprocess

    ffprobe = "ffprobe"
    try:
        out = subprocess.run(
            [
                ffprobe, "-v", "error", "-show_entries", "format=duration",
                "-of", "json", str(video),
            ],
            capture_output=True, text=True, timeout=60,
        )
        duration = float(json.loads(out.stdout)["format"]["duration"])
        if duration > 0:
            return max(0.5, min(4.0, target / duration))
    except Exception as exc:  # noqa: BLE001
        log(f"ffprobe duration probe failed ({exc}); defaulting to 2 fps.")
    return 2.0
