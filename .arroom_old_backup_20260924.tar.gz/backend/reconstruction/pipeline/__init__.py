"""Room-reconstruction pipeline.

Stages (see runner.run):
    1. frames   — video/photos -> undistorted input images        (frames.py)
    2. colmap   — Structure-from-Motion camera poses + sparse pts  (colmap.py)
    3. splat    — 3D Gaussian Splatting scene                      (splat.py)
    4. geometry — mesh + RANSAC floor/wall plane detection         (geometry.py)
    5. scale    — metric calibration (known object / AR)           (scale.py)

Each stage raises `StageError` with a human-readable message on failure (e.g. a
missing external tool) so the API surfaces exactly what went wrong.
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from typing import Callable, Optional


class StageError(RuntimeError):
    """Raised by a stage when it cannot complete."""


def require_tool(binary: str, hint: str) -> str:
    """Return the resolved path to `binary` or raise StageError with install hint."""
    resolved = shutil.which(binary)
    if not resolved:
        raise StageError(f"'{binary}' not found on PATH. {hint}")
    return resolved


def run_command(
    cmd: list[str],
    cwd: Optional[Path] = None,
    log: Optional[Callable[[str], None]] = None,
    timeout: Optional[int] = None,
) -> None:
    """Run a subprocess, streaming stdout+stderr through `log`. Raise on non-zero."""
    log = log or (lambda _l: None)
    log("$ " + " ".join(cmd))
    proc = subprocess.Popen(
        cmd,
        cwd=str(cwd) if cwd else None,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )
    assert proc.stdout is not None
    try:
        for line in proc.stdout:
            log(line.rstrip())
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.kill()
        raise StageError(f"Command timed out after {timeout}s: {' '.join(cmd)}")
    if proc.returncode != 0:
        raise StageError(f"Command failed (exit {proc.returncode}): {' '.join(cmd)}")
