"""Stage 5 — metric scale calibration.

Reconstruction is scale-free: COLMAP/gsplat units are arbitrary. We recover a
`scale_factor` (metres per raw unit) two ways:

  KNOWN_OBJECT  the user gives the real length (m) of a reference. We approximate
                the reconstruction's dominant span and map it — or, better, the
                caller supplies two picked points (in metadata) whose real distance
                is reference_length_m.
  AR            an ARKit/ARCore sidecar (transforms/depth) is already metric; we
                read its camera-translation scale vs COLMAP's and take the ratio.

Everything (planes, bbox) is multiplied by the factor so the viewer is in metres.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np


def calibrate(scene, geometry: dict, work: Path, log) -> float:
    method = scene.scale_method
    if method == "KNOWN_OBJECT":
        factor = _from_known_object(scene, geometry, log)
    elif method == "AR":
        factor = _from_ar_sidecar(scene, work, geometry, log)
    else:
        log("No scale method selected; leaving scene in raw units (factor=1.0).")
        return 1.0

    _apply(geometry, factor)
    log(f"Applied scale factor {factor:.4f} m/unit.")
    return factor


def _from_known_object(scene, geometry: dict, log) -> float:
    """reference_length_m maps to a measured raw span.

    If metadata['ref_points'] = [[x,y,z],[x,y,z]] is provided, use their raw
    distance. Otherwise fall back to the largest floor extent as the reference.
    """
    real = scene.reference_length_m
    if not real:
        raise ValueError("KNOWN_OBJECT calibration needs reference_length_m.")

    pts = (scene.metadata or {}).get("ref_points")
    if pts and len(pts) == 2:
        raw = float(np.linalg.norm(np.array(pts[0]) - np.array(pts[1])))
        log(f"Reference span from picked points: {raw:.4f} raw units.")
    else:
        floors = [p for p in geometry["planes"] if p["type"] == "floor"]
        target = floors[0] if floors else max(geometry["planes"], key=lambda p: p["inliers"])
        raw = max(target["extent"])
        log(f"No ref_points given; using largest floor extent {raw:.4f} as reference.")

    if raw <= 0:
        raise ValueError("Reference raw distance is zero.")
    return real / raw


def _from_ar_sidecar(scene, work: Path, geometry: dict, log) -> float:
    """Compare AR (metric) camera track length to COLMAP's raw track length.

    Expects an uploaded `transforms.json` (Nerfstudio/ARKit style) with per-frame
    `transform_matrix`; its translation is metric. We compare its bbox diagonal to
    the reconstruction bbox diagonal.
    """
    sidecar = work / "ar" / "transforms.json"
    if not sidecar.exists():
        raise ValueError(
            "AR calibration selected but no transforms.json sidecar was found under "
            "the AR upload. Provide ARKit/ARCore poses."
        )
    data = json.loads(sidecar.read_text())
    cams = np.array(
        [np.array(f["transform_matrix"])[:3, 3] for f in data.get("frames", [])]
    )
    if len(cams) < 2:
        raise ValueError("AR sidecar has too few camera poses.")
    ar_diag = float(np.linalg.norm(cams.max(axis=0) - cams.min(axis=0)))
    raw_diag = float(
        np.linalg.norm(np.array(geometry["bbox_max"]) - np.array(geometry["bbox_min"]))
    )
    if raw_diag <= 0:
        raise ValueError("Reconstruction bbox diagonal is zero.")
    log(f"AR diag={ar_diag:.3f} m, raw diag={raw_diag:.3f} units.")
    return ar_diag / raw_diag


def _apply(geometry: dict, factor: float) -> None:
    for key in ("bbox_min", "bbox_max"):
        geometry[key] = (np.array(geometry[key]) * factor).tolist()
    for p in geometry["planes"]:
        p["centroid"] = (np.array(p["centroid"]) * factor).tolist()
        p["extent"] = (np.array(p["extent"]) * factor).tolist()
        p["d"] = float(p["d"]) * factor  # plane offset scales with distance
    geometry["unit"] = "m"
    geometry["scale_factor"] = factor
