"""End-to-end orchestrator. Called by the Celery task; updates the Scene as it goes."""
from __future__ import annotations

import shutil
import traceback
from pathlib import Path

from django.conf import settings

from .. import storage
from . import StageError, colmap, frames, geometry, scale, splat


def run(scene) -> None:
    """Run all stages for a Scene. Persists progress, artifacts and errors."""
    work = Path(settings.WORKSPACE_ROOT) / str(scene.id)
    work.mkdir(parents=True, exist_ok=True)
    log = _logger(scene)

    try:
        scene.metadata = scene.metadata or {}
        upload_path = Path(scene.upload.path)

        # 1. frames
        scene.set_stage("frames", 5)
        images_dir = work / "images"
        n = frames.extract_frames(upload_path, scene.source_type, images_dir, log)
        scene.metadata["frame_count"] = n

        # 2. COLMAP SfM
        scene.set_stage("colmap", 20)
        colmap_dir = colmap.run_sfm(images_dir, work, log)
        points_ply = colmap_dir / "sparse" / "0" / "points.ply"
        scene.sparse_key = storage.upload_file(points_ply, f"{scene.id}/sparse.ply")

        # 3. Gaussian splatting
        scene.set_stage("splat", 45)
        splat_ply = splat.train_splat(colmap_dir, work, log)
        scene.splat_key = storage.upload_file(splat_ply, f"{scene.id}/scene.ply")

        # 4. geometry / planes
        scene.set_stage("geometry", 80)
        geo = geometry.extract_planes(points_ply, log)

        # 5. scale calibration
        scene.set_stage("scale", 92)
        factor = scale.calibrate(scene, geo, work, log)
        scene.scale_factor = factor
        scene.planes = geo
        scene.save(update_fields=["sparse_key", "splat_key", "scale_factor", "planes",
                                  "metadata", "updated_at"])

        scene.mark_done()
        log("Pipeline complete.")
    except StageError as exc:
        log(f"STAGE FAILED: {exc}")
        scene.mark_failed(str(exc))
    except Exception as exc:  # noqa: BLE001
        log("UNEXPECTED ERROR:\n" + traceback.format_exc())
        scene.mark_failed(f"{type(exc).__name__}: {exc}")
    finally:
        # Keep artifacts if it failed (for debugging); clean up on success.
        if scene.status == scene.Status.DONE and not settings.DEBUG:
            shutil.rmtree(work, ignore_errors=True)


def _logger(scene):
    def log(line: str):
        print(f"[{scene.id}] {line}", flush=True)
        scene.append_log(line)
    return log
