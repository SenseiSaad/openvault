"""Stage 2 — COLMAP Structure-from-Motion.

Produces, under work/colmap/:
    database.db
    sparse/0/            (cameras.bin, images.bin, points3D.bin)   <- poses
    sparse/0/points.ply  (sparse point cloud, for the geometry stage)
    images/              (symlink/copy of the input frames)

The output directory is laid out how Nerfstudio's Colmap dataparser expects, so the
splat stage can point `ns-train splatfacto --data <work/colmap>` straight at it.
"""
from __future__ import annotations

import shutil
from pathlib import Path

from django.conf import settings

from . import StageError, require_tool, run_command

_HINT = (
    "Install COLMAP (`sudo apt install colmap`, `brew install colmap`, or build with "
    "CUDA for speed) and/or set COLMAP_BIN in .env."
)


def run_sfm(images_dir: Path, work: Path, log) -> Path:
    """Run COLMAP SfM. Returns the colmap output dir. Raises StageError on failure."""
    colmap = require_tool(settings.COLMAP_BIN, _HINT)

    colmap_dir = work / "colmap"
    colmap_dir.mkdir(parents=True, exist_ok=True)
    db = colmap_dir / "database.db"
    sparse = colmap_dir / "sparse"
    sparse.mkdir(exist_ok=True)

    # Nerfstudio expects the frames under <data>/images.
    staged_images = colmap_dir / "images"
    if not staged_images.exists():
        shutil.copytree(images_dir, staged_images)

    gpu = "0" if _cuda_available() else "-1"
    log(f"COLMAP feature extraction (GPU={'on' if gpu != '-1' else 'off'})...")
    run_command(
        [
            colmap, "feature_extractor",
            "--database_path", str(db),
            "--image_path", str(staged_images),
            "--ImageReader.single_camera", "1",
            "--ImageReader.camera_model", "OPENCV",
            "--SiftExtraction.use_gpu", "1" if gpu != "-1" else "0",
        ],
        log=log,
    )

    log("COLMAP feature matching (exhaustive)...")
    run_command(
        [
            colmap, "exhaustive_matcher",
            "--database_path", str(db),
            "--SiftMatching.use_gpu", "1" if gpu != "-1" else "0",
        ],
        log=log,
    )

    log("COLMAP mapping (this is the slow part)...")
    run_command(
        [
            colmap, "mapper",
            "--database_path", str(db),
            "--image_path", str(staged_images),
            "--output_path", str(sparse),
        ],
        log=log,
    )

    model0 = sparse / "0"
    if not (model0 / "images.bin").exists():
        raise StageError(
            "COLMAP produced no reconstruction. Usually means too little overlap "
            "between frames or a textureless scene — recapture with ~70-80% overlap."
        )

    # Export the sparse points as PLY for the geometry stage.
    log("Exporting sparse point cloud (PLY)...")
    run_command(
        [
            colmap, "model_converter",
            "--input_path", str(model0),
            "--output_path", str(model0 / "points.ply"),
            "--output_type", "PLY",
        ],
        log=log,
    )
    return colmap_dir


def _cuda_available() -> bool:
    if settings.PIPELINE_FORCE_CPU:
        return False
    return shutil.which("nvidia-smi") is not None
