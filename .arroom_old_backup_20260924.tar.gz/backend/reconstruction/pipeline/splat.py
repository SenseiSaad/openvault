"""Stage 3 — 3D Gaussian Splatting via Nerfstudio's `splatfacto` (gsplat backend).

Trains a per-scene splat from the COLMAP output, then exports a `.ply` splat file
the browser viewer can load. Requires nerfstudio + gsplat installed in the venv
(`pip install nerfstudio`) and a CUDA GPU.
"""
from __future__ import annotations

import shutil
from pathlib import Path

from django.conf import settings

from . import StageError, require_tool, run_command

_HINT = (
    "Install the splatting backend into this venv: `pip install nerfstudio` (pulls in "
    "gsplat + the `ns-train` CLI). Needs a CUDA GPU."
)


def train_splat(colmap_dir: Path, work: Path, log, max_iters: int = 15000) -> Path:
    """Train splatfacto and export a splat .ply. Returns the .ply path."""
    require_tool("ns-train", _HINT)
    require_tool("ns-export", _HINT)

    out_dir = work / "splat"
    out_dir.mkdir(parents=True, exist_ok=True)

    log(f"Training splatfacto ({max_iters} iters)...")
    run_command(
        [
            "ns-train", "splatfacto",
            "--data", str(colmap_dir),
            "--output-dir", str(out_dir),
            "--max-num-iterations", str(max_iters),
            "--viewer.quit-on-train-completion", "True",
            "--vis", "tensorboard",
            "colmap",  # dataparser
        ],
        log=log,
    )

    config = _find_config(out_dir)
    if not config:
        raise StageError("Training finished but no config.yml was produced by ns-train.")

    log("Exporting Gaussian splat (.ply)...")
    export_dir = out_dir / "export"
    export_dir.mkdir(exist_ok=True)
    run_command(
        [
            "ns-export", "gaussian-splat",
            "--load-config", str(config),
            "--output-dir", str(export_dir),
        ],
        log=log,
    )

    ply = _find_first(export_dir, "*.ply")
    if not ply:
        raise StageError("ns-export produced no .ply splat file.")
    return ply


def _find_config(root: Path) -> Path | None:
    return _find_first(root, "config.yml")


def _find_first(root: Path, pattern: str) -> Path | None:
    matches = sorted(root.rglob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)
    return matches[0] if matches else None
