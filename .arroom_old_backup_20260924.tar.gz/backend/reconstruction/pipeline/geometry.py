"""Stage 4 — mesh / plane extraction with Open3D.

Loads the COLMAP sparse point cloud and finds the dominant flat surfaces
(floor, ceiling, walls) via iterative RANSAC plane segmentation. Emits a JSON
description the viewer uses to snap furniture to floors/walls.

All lengths here are in raw reconstruction units; scale.py converts to metres.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from . import StageError


def extract_planes(points_ply: Path, log, max_planes: int = 6) -> dict:
    try:
        import open3d as o3d
    except ImportError as exc:  # noqa: BLE001
        raise StageError("open3d not installed — `pip install open3d`.") from exc

    pcd = o3d.io.read_point_cloud(str(points_ply))
    if len(pcd.points) < 100:
        raise StageError("Point cloud too sparse for plane fitting (<100 points).")

    pcd = pcd.voxel_down_sample(voxel_size=0.02)
    pcd, _ = pcd.remove_statistical_outlier(nb_neighbors=20, std_ratio=2.0)
    pts_all = np.asarray(pcd.points)
    scene_centroid = pts_all.mean(axis=0)

    planes = []
    work = pcd
    dist_thresh = _auto_dist_threshold(pts_all)
    for i in range(max_planes):
        if len(work.points) < 50:
            break
        model, inliers = work.segment_plane(
            distance_threshold=dist_thresh, ransac_n=3, num_iterations=1000
        )
        if len(inliers) < 40:
            break
        a, b, c, d = model
        inlier_pts = np.asarray(work.select_by_index(inliers).points)
        normal = np.array([a, b, c], dtype=float)
        normal /= (np.linalg.norm(normal) + 1e-9)
        planes.append(
            {
                "normal": normal.tolist(),
                "d": float(d),
                "centroid": inlier_pts.mean(axis=0).tolist(),
                "inliers": int(len(inliers)),
                "extent": _extent(inlier_pts),
            }
        )
        work = work.select_by_index(inliers, invert=True)
        log(f"  plane {i}: {len(inliers)} inliers, normal={normal.round(2).tolist()}")

    if not planes:
        raise StageError("No planar surfaces found.")

    up = _estimate_up(planes, scene_centroid)
    _classify(planes, up, scene_centroid)

    bbox = pcd.get_axis_aligned_bounding_box()
    result = {
        "up_axis": up.tolist(),
        "planes": planes,
        "bbox_min": np.asarray(bbox.min_bound).tolist(),
        "bbox_max": np.asarray(bbox.max_bound).tolist(),
        "unit": "raw",  # scale.py rewrites this to "m"
        "point_count": len(pcd.points),
    }
    log(f"Detected {len(planes)} planes; up={up.round(2).tolist()}.")
    return result


def _auto_dist_threshold(pts: np.ndarray) -> float:
    span = np.linalg.norm(pts.max(axis=0) - pts.min(axis=0))
    return max(0.01, span * 0.004)


def _extent(pts: np.ndarray) -> list[float]:
    return (pts.max(axis=0) - pts.min(axis=0)).tolist()


def _estimate_up(planes: list[dict], centroid: np.ndarray) -> np.ndarray:
    """Floor is the largest plane; up = its normal, flipped to point above centroid."""
    floor = max(planes, key=lambda p: p["inliers"])
    n = np.array(floor["normal"])
    if np.dot(centroid - np.array(floor["centroid"]), n) < 0:
        n = -n
    return n / (np.linalg.norm(n) + 1e-9)


def _classify(planes: list[dict], up: np.ndarray, centroid: np.ndarray) -> None:
    for p in planes:
        n = np.array(p["normal"])
        vertical = abs(float(np.dot(n, up)))
        above = np.dot(np.array(p["centroid"]) - centroid, up) > 0
        if vertical > 0.85:
            p["type"] = "ceiling" if above else "floor"
        elif vertical < 0.35:
            p["type"] = "wall"
        else:
            p["type"] = "other"
