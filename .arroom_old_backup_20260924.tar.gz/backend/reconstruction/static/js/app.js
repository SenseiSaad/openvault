// Upload form + scene list polling.
const $ = (sel) => document.querySelector(sel);

function getCookie(name) {
  const m = document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)');
  return m ? m.pop() : '';
}

// Toggle the reference-length field based on scale method.
const scaleSel = $('#scale_method');
scaleSel.addEventListener('change', () => {
  $('#ref-wrap').style.display = scaleSel.value === 'KNOWN_OBJECT' ? 'block' : 'none';
});

// Submit upload.
$('#upload-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = $('#submit-btn');
  const err = $('#form-error');
  err.textContent = '';
  btn.disabled = true;
  btn.textContent = 'Uploading…';

  const fd = new FormData(e.target);
  if (scaleSel.value !== 'KNOWN_OBJECT') fd.delete('reference_length_m');

  try {
    const res = await fetch('/api/scenes/', {
      method: 'POST',
      headers: { 'X-CSRFToken': getCookie('csrftoken') },
      body: fd,
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(JSON.stringify(data));
    }
    e.target.reset();
    $('#ref-wrap').style.display = 'none';
    await refresh();
  } catch (ex) {
    err.textContent = 'Upload failed: ' + ex.message;
  } finally {
    btn.disabled = false;
    btn.textContent = 'Upload & reconstruct';
  }
});

function sceneRow(s) {
  const done = s.status === 'DONE';
  const open = done
    ? `<a class="btn" href="/viewer/${s.id}/">Open</a>`
    : `<button class="btn ghost" disabled>Open</button>`;
  const err = s.status === 'FAILED' && s.error
    ? `<div class="error">${escapeHtml(s.error)}</div>` : '';
  return `
    <div class="scene" data-id="${s.id}" data-status="${s.status}">
      <div class="meta">
        <div class="name">${escapeHtml(s.name || 'Untitled room')}</div>
        <div class="sub">${s.source_type} · ${s.stage || '—'} ·
          ${s.scale_method !== 'NONE' ? 'scaled ×' + s.scale_factor.toFixed(3) : 'unscaled'}</div>
        <div class="progress"><i style="width:${s.progress}%"></i></div>
        ${err}
      </div>
      <span class="badge ${s.status}">${s.status}</span>
      ${open}
    </div>`;
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"]/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

async function refresh() {
  const res = await fetch('/api/scenes/');
  const scenes = await res.json();
  const list = $('#scene-list');
  if (!scenes.length) {
    list.innerHTML = '<p class="hint">No rooms yet — upload one to get started.</p>';
    return;
  }
  list.innerHTML = scenes.map(sceneRow).join('');
}

// Poll while anything is still processing.
async function tick() {
  await refresh();
  const active = document.querySelector('.scene[data-status="RUNNING"], .scene[data-status="QUEUED"]');
  setTimeout(tick, active ? 2500 : 8000);
}
tick();
