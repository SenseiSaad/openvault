import * as THREE from 'three';
import * as GaussianSplats3D from '@mkkellogg/gaussian-splats-3d';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

const stage = document.getElementById('stage');
const loadingEl = document.getElementById('loading');
const panel = document.getElementById('panel');

let viewer, floorPlane = null, upAxis = new THREE.Vector3(0, 1, 0);
let selectedModel = null;               // catalog entry chosen for placement
const placed = [];                      // meshes we've added
const gltfLoader = new GLTFLoader();
const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();

// Placeholder catalog. Real .glb models are listed in
// static/furniture/manifest.json (drop files there); the box always works.
const FALLBACK_CATALOG = [{ name: 'Box (1m)', kind: 'box' }];

async function main() {
  const scene = await (await fetch(`/api/scenes/${window.SCENE_ID}/`)).json();
  if (scene.status !== 'DONE' || !scene.splat_url) {
    loadingEl.textContent = 'Scene is not ready yet (status: ' + scene.status + ').';
    return;
  }

  const geo = scene.planes || {};
  if (Array.isArray(geo.up_axis)) upAxis = new THREE.Vector3(...geo.up_axis).normalize();
  const scale = scene.scale_factor || 1.0;

  viewer = new GaussianSplats3D.Viewer({
    rootElement: stage,
    cameraUp: upAxis.toArray(),
    initialCameraPosition: [0, 1.6, 4],
    initialCameraLookAt: [0, 1, 0],
    sphericalHarmonicsDegree: 0,
  });

  // scale maps raw splat units -> metres, matching the metric planes/furniture.
  await viewer.addSplatScene(scene.splat_url, {
    scale: [scale, scale, scale],
    showLoadingUI: false,
  });
  viewer.start();

  loadingEl.style.display = 'none';
  panel.style.display = 'block';
  buildFloorPlane(geo);
  showRoomInfo(scene, geo);
  await buildCatalog();
  installPlacement();
}

// PLACEHOLDER_APPEND

function buildFloorPlane(geo) {
  const floor = (geo.planes || []).find((p) => p.type === 'floor');
  if (!floor) return;
  const n = new THREE.Vector3(...floor.normal).normalize();
  // Orient normal along up so furniture sits on top.
  if (n.dot(upAxis) < 0) n.negate();
  const point = new THREE.Vector3(...floor.centroid);
  floorPlane = new THREE.Plane().setFromNormalAndCoplanarPoint(n, point);
}

function showRoomInfo(scene, geo) {
  const el = document.getElementById('room-info');
  const dims = (geo.bbox_min && geo.bbox_max)
    ? geo.bbox_max.map((v, i) => Math.abs(v - geo.bbox_min[i]).toFixed(2))
    : null;
  const nWalls = (geo.planes || []).filter((p) => p.type === 'wall').length;
  el.innerHTML = `
    ${escapeHtml(scene.name || 'Untitled')}<br>
    Units: ${geo.unit === 'm' ? 'metres (calibrated)' : 'relative'}<br>
    ${dims ? `Approx. size: ${dims[0]} × ${dims[1]} × ${dims[2]} m<br>` : ''}
    Walls detected: ${nWalls}`;
}

async function buildCatalog() {
  let items = FALLBACK_CATALOG.slice();
  try {
    const res = await fetch('/static/furniture/manifest.json');
    if (res.ok) {
      const manifest = await res.json();
      items = items.concat(manifest.models || []);
    }
  } catch (_) { /* manifest optional */ }

  const el = document.getElementById('catalog');
  el.innerHTML = '';
  items.forEach((item) => {
    const div = document.createElement('div');
    div.className = 'item';
    div.textContent = item.name;
    div.addEventListener('click', () => {
      selectedModel = item;
      [...el.children].forEach((c) => (c.style.borderColor = ''));
      div.style.borderColor = 'var(--accent)';
    });
    el.appendChild(div);
  });
}

function installPlacement() {
  const canvas = viewer.renderer.domElement;
  canvas.addEventListener('pointerdown', (e) => {
    if (!selectedModel || !floorPlane || e.button !== 0) return;
    // Only place on a deliberate click (shift) to avoid fighting orbit controls.
    if (!e.shiftKey) return;
    const rect = canvas.getBoundingClientRect();
    pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(pointer, viewer.camera);
    const hit = new THREE.Vector3();
    if (raycaster.ray.intersectPlane(floorPlane, hit)) placeAt(hit);
  });
  document.getElementById('clear-btn').addEventListener('click', clearFurniture);

  // Hint about shift-click.
  const info = document.getElementById('room-info');
  info.insertAdjacentHTML('afterend',
    '<p class="hint" style="margin-top:8px">Hold <b>Shift</b> and click the floor to place.</p>');
}

function placeAt(point) {
  if (selectedModel.kind === 'box') {
    const box = new THREE.Mesh(
      new THREE.BoxGeometry(1, 1, 1),
      new THREE.MeshStandardMaterial({ color: 0x5b8cff, opacity: 0.85, transparent: true }),
    );
    box.position.copy(point).addScaledVector(upAxis, 0.5); // sit on floor
    addToScene(box);
    return;
  }
  gltfLoader.load(selectedModel.url, (gltf) => {
    const obj = gltf.scene;
    obj.position.copy(point);
    orientToUp(obj);
    addToScene(obj);
  }, undefined, (err) => console.error('GLB load failed', err));
}

function orientToUp(obj) {
  // Models are authored Y-up; rotate so their Y matches the scene up axis.
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), upAxis);
  obj.quaternion.copy(q);
}

function addToScene(obj) {
  ensureLights();
  viewer.threeScene.add(obj);
  placed.push(obj);
}

let lit = false;
function ensureLights() {
  if (lit) return;
  const amb = new THREE.AmbientLight(0xffffff, 0.8);
  const dir = new THREE.DirectionalLight(0xffffff, 0.6);
  dir.position.copy(upAxis).multiplyScalar(5);
  viewer.threeScene.add(amb, dir);
  lit = true;
}

function clearFurniture() {
  placed.forEach((o) => viewer.threeScene.remove(o));
  placed.length = 0;
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"]/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

main().catch((e) => { loadingEl.textContent = 'Viewer error: ' + e.message; console.error(e); });
