from django.contrib import admin

from .models import Scene


@admin.register(Scene)
class SceneAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "source_type", "status", "stage", "progress", "created_at")
    list_filter = ("status", "source_type", "scale_method")
    search_fields = ("id", "name")
    readonly_fields = ("id", "created_at", "updated_at", "log")
