from celery import shared_task

from .models import Scene


@shared_task(name="reconstruction.run_pipeline", bind=True)
def run_pipeline(self, scene_id: str):
    """Async entrypoint. Loads the Scene and runs the full reconstruction pipeline."""
    # Imported lazily so Django/Celery start even if heavy deps (open3d) are absent
    # until a job actually runs.
    from .pipeline import runner

    try:
        scene = Scene.objects.get(id=scene_id)
    except Scene.DoesNotExist:
        return {"error": f"Scene {scene_id} not found"}

    runner.run(scene)
    return {"scene": str(scene.id), "status": scene.status}
